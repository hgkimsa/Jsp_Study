package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Controller.PingDTO;
import Controller.TiniDTO;

public class TiniDAO {

	// 공통 필드 선언
	PreparedStatement psmt = null;
	Connection conn = null;
	ResultSet rs = null;
	int row = 0;

	// DB 연결 메소드
	private void getConn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@project-db-campus.smhrd.com:1524:xe";
			String user = "cgi_24k_bigdata26_p1_1";
			String password = "smhrd1";

			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// 자원반납 메소드
	private void getClose() {
		try {
			if (rs != null) {
				rs.close();

			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	// 회원가입 메서드
	public int join(String id, String pw, String name, int age) {

		try {
			// DB 연결 메소드 호출
			getConn();

			String sql = "INSERT INTO Tini_Member VALUES(?, ?, ?, ?)";

			psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.setString(2, pw);
			psmt.setString(3, name);
			psmt.setInt(4, age);

			row = psmt.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();

		} finally {
			getClose();
		}
		return row;
	}

	// 로그인 메서드

	public TiniDTO login(String id, String pw) {

		TiniDTO dto = null;

		try {
			getConn();

			String sql = "SELECT * FROM Tini_Member  WHERE ID = ? AND PW = ?";

			psmt = conn.prepareStatement(sql);

			psmt.setString(1, id);
			psmt.setString(2, pw);

			rs = psmt.executeQuery();

			if (rs.next() == true) {

				String name = rs.getString("name");
				int age = rs.getInt("age");
				// rs에 있는 데이터를 DTO에 옮겨담기
				dto = new TiniDTO();
				dto.setName(name);
				dto.setAge(age);
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			getClose();
		}
		return dto;
	}

	// 회원탈퇴 메서드
	public int delete(String id, String pw) {

		try {
			getConn();

			String sql = "DELETE FROM Tini_Member WHERE ID = ? AND PW = ?";

			psmt = conn.prepareStatement(sql);

			psmt.setString(1, id);
			psmt.setString(2, pw);

			row = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			getClose();
		}
		return row;
	}

	// 저장 메소드
	public int save(String name, String id, int exp, int lev, int feed, int hp, int joy, int tired) {

		try {
			// DB 연결 메소드 호출
			getConn();

			String sql = "INSERT INTO TINIPING VALUES(?, ?, ?, ?, ?, ?, ?, ?)";

			psmt = conn.prepareStatement(sql);
			psmt.setString(1, name);
			psmt.setString(2, id);
			psmt.setInt(3, exp);
			psmt.setInt(4, lev);
			psmt.setInt(5, feed);
			psmt.setInt(6, hp);
			psmt.setInt(7, joy);
			psmt.setInt(8, tired);

			row = psmt.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();

		} finally {
			getClose();
		}
		return row;

	}

	// ID에 맞는 정보 조회 메서드
	public ArrayList<PingDTO> select(String id) {

		PingDTO dto = null;
		ArrayList<PingDTO> list = new ArrayList<PingDTO>();

		try {
			getConn();

			String sql = "Select ID, NAME, EXP, LEV, FEED, HP, JOY, TIRED FROM TINIPING WHERE ID = ?";

			psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);

			rs = psmt.executeQuery();

			while (rs.next()) {

				String id1 = rs.getString("ID");
				String name = rs.getString("NAME");
				int exp = rs.getInt("EXP");
				int lev = rs.getInt("LEV");
				int feed = rs.getInt("FEED");
				int hp = rs.getInt("HP");
				int joy = rs.getInt("JOY");
				int tired = rs.getInt("TIRED");
				dto = new PingDTO();
				dto.setId(id1);
				dto.setName(name);
				dto.setExp(exp);
				dto.setLev(lev);
				dto.setFeed(feed);
				dto.setHp(hp);
				dto.setJoy(joy);
				dto.setTired(tired);

				// ArrayList를 이용해서 모든 회원데이터를 묶어주기
				list.add(dto);

			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			getClose();
		}
		return list;

	}

	// 불러오기 메소드

	// 업데이트 메소드 하츄핑
	public int update1(String name, String id, int exp, int lev, int feed, int hp, int joy, int tired) {

		try {
			getConn();

			String sql = "UPDATE TINIPING SET EXP = ?, LEV = ?, FEED = ?, HP = ?, JOY = ?, TIRED = ? WHERE ID = ? AND NAME = ?";

			psmt = conn.prepareStatement(sql);

			psmt.setInt(1, exp);
			psmt.setInt(2, lev);
			psmt.setInt(3, feed);
			psmt.setInt(4, hp);
			psmt.setInt(5, joy);
			psmt.setInt(6, tired);
			psmt.setString(7, id);
			psmt.setString(8, "하츄핑");

			row = psmt.executeUpdate();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			getClose();
		}
		return row;
	}
	
	// 업데이트 메소드 아주핑
		public int update2(String name, String id, int exp, int lev, int feed, int hp, int joy, int tired) {

			try {
				getConn();

				String sql = "UPDATE TINIPING SET EXP = ?, LEV = ?, FEED = ?, HP = ?, JOY = ?, TIRED = ? WHERE ID = ? AND NAME = ?";

				psmt = conn.prepareStatement(sql);

				psmt.setInt(1, exp);
				psmt.setInt(2, lev);
				psmt.setInt(3, feed);
				psmt.setInt(4, hp);
				psmt.setInt(5, joy);
				psmt.setInt(6, tired);
				psmt.setString(7, id);
				psmt.setString(8, "아자핑");
				
				row = psmt.executeUpdate();
			} catch (Exception e) {

				e.printStackTrace();
			} finally {
				getClose();
			}
			return row;
		}

}
