package miniProject;

public class main2차 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
