package miniProject;

import java.util.ArrayList;
import java.util.Scanner;

import Controller.PingDTO;
import Controller.Tini;
import Controller.TiniDTO;

import Model.TiniDAO;

public class main1차 {
   public static void main(String[] args) {

      Scanner sc = new Scanner(System.in);

      Tini hacyu = new Tini("하츄핑", 0, 1, 3, 2, 5, 0);
      Tini ajya = new Tini("아자핑", 0, 1, 1, 5, 4, 0);

      System.out.println("==== 티니핑 키우기 ====");

      while (true) {
         System.out.print("[1] 회원가입 [2] 로그인 [3] 회원탈퇴 [4] 프로그램 종료 >> ");
         int game = sc.nextInt();
         if (game == 1) {

            System.out.println("===== 회원 가입 =====");
            System.out.print("ID 입력 : ");
            String id = sc.next();
            System.out.print("PW 입력 : ");
            String pw = sc.next();
            System.out.print("이름 입력 : ");
            String name = sc.next();
            System.out.print("나이 입력 : ");
            int age = sc.nextInt();

            TiniDAO dao = new TiniDAO();
            int row = dao.join(id, pw, name, age);

            if (row > 0) {
               System.out.println("회원가입 성공");
            } else {
               System.out.println("회원가입 실패");
            }

         } else if (game == 2) {
            System.out.println("==== 로그인 ====");
            System.out.print("ID 입력 : ");
            String id = sc.next();
            System.out.print("PW 입력 : ");
            String pw = sc.next();

            TiniDAO dao = new TiniDAO();
            TiniDTO dto = dao.login(id, pw);

            if (dto != null) {
               String name = dto.getName();
               int age = dto.getAge();
               System.out.println("로그인 성공!");
               System.out.println(name + "(" + age + ") 님 환영합니다.");

               System.out.print("[1] 게임 시작하기 [2] 게임 종료하기 >> ");
               int ping = sc.nextInt();
               if (ping == 1) {

                  System.out.println("티니핑 키우기 게임을 시작합니다");
                  System.out.print("[1] 새로 시작하기 [2] 저장 불러오기 [3] 게임 종료하기 >> ");
                  int choice = sc.nextInt();
                  System.out.println();
                  if (choice == 1) {
                     // 티니핑 능력치 소개
                     System.out.println("[1] 하츄핑 : 사랑과 배려가 넘치는 하츄핑!!");
                     System.out.println("체력: 2, 포만감: 3, 즐거움: 5");

                     System.out.println("[2] 아자핑 : 운동을 좋아하고 성격이 터프한 아자핑 !!");
                     System.out.println("체력: 5, 포만감: 1, 즐거움: 4");

                     System.out.println();

                     System.out.print("캐릭터를 선택해주세요 : >> ");
                     int act = sc.nextInt();
                     while (true) {
                        if (act == 1) { // 하츄핑 선택
                           System.out.print("[1] 캐릭터 정보보기 [2] 행동하기 [3] 게임 종료하기 >> ");
                           int move = sc.nextInt();
                           if (move == 1) {
                              // 하츄핑 스테이터스 조회
                              System.out.println("레벨: " + hacyu.getLev() + ", 경험치: " + hacyu.getExp()
                                    + ", 체력: " + hacyu.getHp() + ", 포만감: " + hacyu.getFeed() + ", 즐거움: "
                                    + hacyu.getJoy() + ", 피로도: " + hacyu.getTiredness());
                           } else if (move == 2) {
                              System.out.println("행동을 선택해주세요");
                              System.out.print("[1] 운동하기 [2] 식사하기 [3] 친구만나기 [4]휴식하기 >> ");
                              int input4 = sc.nextInt();
                              if (input4 == 1) {
                                 // 운동메소드
                                 hacyu.setHp(hacyu.getHp() + 8);
                                 hacyu.setFeed(hacyu.getFeed() - 2);
                                 hacyu.setJoy(hacyu.getJoy() + 3);
                                 hacyu.setTiredness(hacyu.getTiredness() + 3);
                                 hacyu.setExp(hacyu.getExp() + 2);
                                 if (hacyu.getExp() == 10) {
                                    hacyu.setLev(hacyu.getLev() + 1);
                                    hacyu.setExp(hacyu.getExp() - 10);
                                 }

                                 System.out.println();
                                 System.out.println("운동을 해서 하츄핑의 체력이 좋아졌어요!");
                                 System.out.println();

                              } else if (input4 == 2) {
                                 // 식사메소드
                                 hacyu.setHp(hacyu.getHp() + 2);
                                 hacyu.setFeed(hacyu.getFeed() + 8);
                                 hacyu.setJoy(hacyu.getJoy() - 2);
                                 hacyu.setTiredness(hacyu.getTiredness() + 3);
                                 hacyu.setExp(hacyu.getExp() + 2);
                                 if (hacyu.getExp() == 10) {
                                    hacyu.setLev(hacyu.getLev() + 1);
                                    hacyu.setExp(hacyu.getExp() - 10);
                                 }

                                 System.out.println();
                                 System.out.println("밥을 먹은 하츄핑의 배가 빵빵해졌어요!");
                                 System.out.println();

                              } else if (input4 == 3) {
                                 // 친구메소드
                                 hacyu.setHp(hacyu.getHp() - 2);
                                 hacyu.setFeed(hacyu.getFeed() - 2);
                                 hacyu.setJoy(hacyu.getJoy() + 8);
                                 hacyu.setTiredness(hacyu.getTiredness() + 3);
                                 hacyu.setExp(hacyu.getExp() + 2);
                                 if (hacyu.getExp() == 10) {
                                    hacyu.setLev(hacyu.getLev() + 1);
                                    hacyu.setExp(hacyu.getExp() - 10);
                                 }

                                 System.out.println();
                                 System.out.println("친구를 만난 하츄핑의 기분이업됐어요!!");
                                 System.out.println();

                              } else if (input4 == 4) {
                                 // 휴식메소드
                                 hacyu.setHp(hacyu.getHp() + 2);
                                 hacyu.setFeed(hacyu.getFeed() - 2);
                                 hacyu.setJoy(hacyu.getJoy() - 2);
                                 hacyu.setTiredness(hacyu.getTiredness() - 8);
                                 hacyu.setExp(hacyu.getExp() + 2);
                                 if (hacyu.getExp() == 10) {
                                    hacyu.setLev(hacyu.getLev() + 1);
                                    hacyu.setExp(hacyu.getExp() - 10);
                                 }

                                 System.out.println();
                                 System.out.println("푹 쉬어서 하츄핑의 피로가 사라졌어요!!");
                                 System.out.println();

                              }

                           } else if (move == 3) {
                              System.out.println("게임을 종료합니다");
                              // 캐릭터의 정보를 아이디별로 데이터베이스에 저장하는 명령식적기
                              TiniDAO dao1 = new TiniDAO();
                              int row = dao1.save(hacyu.getName(), id, hacyu.getExp(), hacyu.getLev(),
                                    hacyu.getFeed(), hacyu.getHp(), hacyu.getJoy(), hacyu.getTiredness());

                              if (row > 0) {
                                 System.out.println("저장 성공");
                              } else {
                                 System.out.println("저장 실패");
                              }
                              break;
                           } else {
                              System.out.println("잘못입력하셨습니다");
                           }
                        } else if (act == 2) { // 아자핑 선택
                           System.out.print("[1] 캐릭터 정보보기 [2] 행동하기 [3] 게임 종료하기 >> ");
                           int move = sc.nextInt();
                           if (move == 1) {
                              // 아자핑 스테이터스 조회
                              System.out.println("레벨: " + ajya.getLev() + ", 경험치: " + ajya.getExp() + ", 체력: "
                                    + ajya.getHp() + ", 포만감: " + ajya.getFeed() + ", 즐거움: " + ajya.getJoy()
                                    + ", 피로도: " + ajya.getTiredness());
                           } else if (move == 2) {
                              System.out.println("행동을 선택해주세요");
                              System.out.print("[1] 운동하기 [2] 식사하기 [3] 친구만나기 [4]휴식하기 >> ");
                              int input4 = sc.nextInt();
                              if (input4 == 1) {
                                 // 운동메소드
                                 ajya.setHp(ajya.getHp() + 5);
                                 ajya.setFeed(ajya.getFeed() - 1);
                                 ajya.setJoy(ajya.getJoy() + 2);
                                 ajya.setTiredness(ajya.getTiredness() + 4);
                                 ajya.setExp(ajya.getExp() + 3);
                                 if (ajya.getExp() == 10) {
                                    ajya.setLev(ajya.getLev() + 1);
                                    ajya.setExp(ajya.getExp() - 10);
                                 }

                                 System.out.println();
                                 System.out.println("운동을 해서 아자핑의 체력이 좋아졌어요!");
                                 System.out.println();

                              } else if (input4 == 2) {
                                 // 식사메소드
                                 ajya.setHp(ajya.getHp() + 3);
                                 ajya.setFeed(ajya.getFeed() + 8);
                                 ajya.setJoy(ajya.getJoy() - 2);
                                 ajya.setTiredness(ajya.getTiredness() + 3);
                                 ajya.setExp(ajya.getExp() + 2);
                                 if (ajya.getExp() == 10) {
                                    ajya.setLev(ajya.getLev() + 1);
                                    ajya.setExp(ajya.getExp() - 10);
                                 }

                                 System.out.println();
                                 System.out.println("밥을 먹은 아자핑의 배가 빵빵해졌어요!");
                                 System.out.println();

                              } else if (input4 == 3) {
                                 // 친구메소드
                                 ajya.setHp(ajya.getHp() - 1);
                                 ajya.setFeed(ajya.getFeed() - 1);
                                 ajya.setJoy(ajya.getJoy() + 8);
                                 ajya.setTiredness(ajya.getTiredness() + 2);
                                 ajya.setExp(ajya.getExp() + 2);
                                 if (ajya.getExp() == 10) {
                                    ajya.setLev(ajya.getLev() + 1);
                                    ajya.setExp(ajya.getExp() - 10);
                                 }

                                 System.out.println();
                                 System.out.println("친구를 만난 아자핑의 기분이 업됐어요!!");
                                 System.out.println();

                              } else if (input4 == 4) {
                                 // 휴식메소드
                                 ajya.setHp(ajya.getHp() + 2);
                                 ajya.setFeed(ajya.getFeed() - 2);
                                 ajya.setJoy(ajya.getJoy() - 2);
                                 ajya.setTiredness(ajya.getTiredness() - 8);
                                 ajya.setExp(ajya.getExp() + 2);
                                 if (ajya.getExp() == 10) {
                                    ajya.setLev(ajya.getLev() + 1);
                                    ajya.setExp(ajya.getExp() - 10);
                                 }

                                 System.out.println();
                                 System.out.println("푹 쉬어서 아자핑의 피로가 사라졌어요!!");
                                 System.out.println();

                              }

                           } else if (move == 3) {
                              System.out.println("게임을 종료합니다");
                              // 캐릭터의 정보를 아이디별로 데이터베이스에 저장하는 명령식적기
                              TiniDAO dao1 = new TiniDAO();
                              int row = dao1.save(ajya.getName(), id, ajya.getExp(), ajya.getLev(), ajya.getFeed(),
                                    ajya.getHp(), ajya.getJoy(), ajya.getTiredness());

                              if (row > 0) {
                                 System.out.println("저장 성공");
                              } else {
                                 System.out.println("저장 실패");
                              }
                              break;
                           } else {
                              System.out.println("잘못입력하셨습니다");
                           }
                        } else {
                           System.out.println("잘못입력하셨습니다");
                        }
                     }
                  } else if (choice == 2) {
                     System.out.println("저장된 데이터를 불러옵니다");
                     // 데이터베이스에서 저장된 데이터 불러오기 명령
                     TiniDAO dao1 = new TiniDAO();
                     // hacyu = dao1.load(id); // 특정 사용자 ID로부터 정보 불러오기
                     // ajya = dao1.load(id);
                     // 각 티니에 대한 정보를 데이터베이스에서 불러오는 코드를 구현해야 함
                  } else if (choice == 3) {
                     System.out.println("게임을 종료합니다");
                     break;
                  }
               }

            } else {
               System.out.println("로그인 실패");
            }

         } else if (game == 3) {
            System.out.println("===== 회원 탈퇴 =====");
            System.out.print("ID 입력 : ");
            String id = sc.next();
            System.out.print("PW 입력 : ");
            String pw = sc.next();

            TiniDAO dao = new TiniDAO();
            int row = dao.delete(id, pw);

            if (row > 0) {
               System.out.println("회원탈퇴 성공");
            } else {
               System.out.println("회원탈퇴 실패");
            }

         } else if (game == 4) {
            System.out.println("프로그램을 종료합니다.");
            break;
         } else {
            System.out.println("잘못입력하셨습니다");
         }

      }

      sc.close();
   }
}
