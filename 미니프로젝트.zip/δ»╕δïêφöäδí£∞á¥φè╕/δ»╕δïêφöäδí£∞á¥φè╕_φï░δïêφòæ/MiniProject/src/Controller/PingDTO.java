package Controller;

public class PingDTO {

	private String name;
	private String id;
	private int exp;
	private int lev;
	private int feed;
	private int hp;
	private int joy;
	private int tired;
	
	public PingDTO() {
		
	}

	public PingDTO(String name, String id, int exp, int lev, int feed, int hp, int joy, int tired) {
		super();
		this.name = name;
		this.id = id;
		this.exp = exp;
		this.lev = lev;
		this.feed = feed;
		this.hp = hp;
		this.joy = joy;
		this.tired = tired;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getExp() {
		return exp;
	}
	public void setExp(int exp) {
		this.exp = exp;
	}
	public int getLev() {
		return lev;
	}
	public void setLev(int lev) {
		this.lev = lev;
	}
	public int getFeed() {
		return feed;
	}
	public void setFeed(int feed) {
		this.feed = feed;
	}
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	public int getJoy() {
		return joy;
	}
	public void setJoy(int joy) {
		this.joy = joy;
	}
	public int getTired() {
		return tired;
	}
	public void setTired(int tired) {
		this.tired = tired;
	}
	
}
