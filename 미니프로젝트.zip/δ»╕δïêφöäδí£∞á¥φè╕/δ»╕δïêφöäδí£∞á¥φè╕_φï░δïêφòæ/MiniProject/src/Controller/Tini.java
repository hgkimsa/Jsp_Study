package Controller;

public class Tini {
	
	// 1. 필드
	   // 이름(및 소개), 체력, 피로도, 포만감, 즐거움, 경험치, 레벨

	   protected String name; // 이름
	   // protected String id; // 아이디
	   protected int exp; // 경험치
	   protected int lev; // 레벨
	   protected int feed; // 포만감
	   protected int hp; // 체력
	   protected int joy; // 즐거움
	   protected int tiredness; // 피로도

	   // 생성자 메소드
	   public Tini(String name, int exp, int lev, int feed, int hp, int joy, int tiredness) {
	      super();
	      this.name = name;
	      // this.id = id;
	      this.exp = exp;
	      this.lev = lev;
	      this.feed = feed;
	      this.hp = hp;
	      this.joy = joy;
	      this.tiredness = tiredness;
	   }

	   public String getName() {
	      return name;
	   }

	   public void setName(String name) {
	      this.name = name;
	   }

	   public int getExp() {
	      return exp;
	   }

	   public void setExp(int exp) {
	      this.exp = exp;
	   }

	   public int getLev() {
	      return lev;
	   }

	   public void setLev(int lev) {
	      this.lev = lev;
	   }

	   public int getFeed() {
	      return feed;
	   }

	   public void setFeed(int feed) {
	      this.feed = feed;
	   }

	   public int getHp() {
	      return hp;
	   }

	   public void setHp(int hp) {
	      this.hp = hp;
	   }

	   public int getJoy() {
	      return joy;
	   }

	   public void setJoy(int joy) {
	      this.joy = joy;
	   }

	   public int getTiredness() {
	      return tiredness;
	   }

	   public void setTiredness(int tiredness) {
	      this.tiredness = tiredness;
	   }

	   // getter, setter 메서드

	

}
