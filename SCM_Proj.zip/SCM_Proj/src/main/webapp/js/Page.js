// 10초마다 뉴스 자동 갱신
setInterval(fetchLatestNews, 10000);/**
 * 
 */